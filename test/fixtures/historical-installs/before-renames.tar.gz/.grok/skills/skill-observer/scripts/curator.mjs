#!/usr/bin/env node

import { existsSync, lstatSync, mkdirSync, readFileSync, realpathSync, renameSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  SkillLoopError,
  applyCuratorTransition,
  assertLearningLoopSupported,
  copySkillTree,
  createLoopContext,
  isAgentOwnedSkill,
  readUsage,
  recoverTransactions,
  withStateLock,
} from './skill-loop.mjs';
import { randomUUID } from 'node:crypto';

const SCRIPT_PATH = fileURLToPath(import.meta.url);
const DAY = 24 * 60 * 60 * 1000;
const RUN_INTERVAL = 7 * DAY;
const MIN_IDLE = 2 * 60 * 60 * 1000;
const STALE_AFTER = 30 * DAY;
const ARCHIVE_AFTER = 90 * DAY;

function fail(code, detail = '') {
  throw new SkillLoopError(code, detail);
}

function ensureDirectory(path) {
  try { mkdirSync(path, { mode: 0o700 }); } catch (error) { if (error?.code !== 'EEXIST') throw error; }
  const status = lstatSync(path);
  if (!status.isDirectory() || status.isSymbolicLink()) fail('CURATOR_PATH_UNSAFE', path);
  return path;
}

function latestActivity(entry) {
  return Math.max(...[
    entry.created_at,
    entry.last_used_at,
    entry.last_viewed_at,
    entry.last_patched_at,
  ].filter(Boolean).map(Date.parse));
}

function curatorStatePath(context) {
  return join(context.stateRoot, 'curator-state.json');
}

function previousRun(context) {
  const path = curatorStatePath(context);
  if (!existsSync(path)) return null;
  let state;
  try { state = JSON.parse(readFileSync(path, 'utf8')); } catch { fail('CURATOR_STATE_INVALID'); }
  if (!state || state.schema !== 'litgrok.curator-state/v1' || typeof state.lastRunAt !== 'string' || !Number.isFinite(Date.parse(state.lastRunAt))) {
    fail('CURATOR_STATE_INVALID');
  }
  return Date.parse(state.lastRunAt);
}

function writeState(context, now) {
  const path = curatorStatePath(context);
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`;
  const text = `${JSON.stringify({ schema: 'litgrok.curator-state/v1', lastRunAt: now }, null, 2)}\n`;
  writeFileSync(temporary, text, { flag: 'wx', mode: 0o600 });
  renameSync(temporary, path);
}

export function runCurator(options = {}) {
  assertLearningLoopSupported(options);
  const context = options.context ?? createLoopContext(options);
  const now = options.now ?? new Date().toISOString();
  const nowMs = Date.parse(now);
  if (!Number.isFinite(nowMs)) fail('TIMESTAMP_INVALID');
  return withStateLock(join(context.stateRoot, 'skill-loop.lock'), () => {
    recoverTransactions(context);
    const lastRun = previousRun(context);
    if (!options.force && lastRun !== null && nowMs - lastRun < RUN_INTERVAL) {
      return { ok: true, skipped: 'interval', stale: [], archived: [], skippedPinned: [] };
    }
    const usage = readUsage(context);
    const candidates = [];
    const skippedPinned = [];
    for (const [skill, entry] of Object.entries(usage.skills).sort(([left], [right]) => left.localeCompare(right))) {
      if (entry.pinned) { skippedPinned.push(skill); continue; }
      if (entry.state === 'archived') continue;
      if (nowMs - latestActivity(entry) < MIN_IDLE) continue;
      if (!isAgentOwnedSkill(context, skill)) continue;
      if (entry.state === 'active' && nowMs - latestActivity(entry) >= STALE_AFTER) candidates.push({ action: 'stale', entry, skill });
      if (entry.state === 'stale' && nowMs - latestActivity(entry) >= ARCHIVE_AFTER) candidates.push({ action: 'archive', entry, skill });
    }

    const runKey = now.replace(/[:.]/g, '-');
    const backupRoot = candidates.length > 0
      ? ensureDirectory(join(ensureDirectory(join(context.stateRoot, 'curator-backups')), runKey))
      : null;
    for (const candidate of candidates) copySkillTree(join(context.userRoot, candidate.skill), join(backupRoot, candidate.skill));

    const stale = [];
    const archived = [];
    for (const candidate of candidates) {
      if (candidate.action === 'stale') {
        applyCuratorTransition({ context, skill: candidate.skill, action: 'stale', now });
        stale.push(candidate.skill);
        continue;
      }
      const archiveRoot = ensureDirectory(join(ensureDirectory(join(context.grokRoot, 'litgrok')), 'archive'));
      const destination = join(archiveRoot, `${candidate.skill}-${runKey}`);
      if (existsSync(destination)) fail('CURATOR_ARCHIVE_CONFLICT', destination);
      applyCuratorTransition({ context, skill: candidate.skill, action: 'archive', now, archivePath: destination });
      archived.push(candidate.skill);
    }
    writeState(context, now);
    return { ok: true, stale, archived, skippedPinned };
  });
}

if (process.argv[1] && realpathSync(resolve(process.argv[1])) === SCRIPT_PATH) {
  const { runSkillLoop } = await import('./skill-loop.mjs');
  process.exitCode = await runSkillLoop(['curator', ...process.argv.slice(2)]);
}
