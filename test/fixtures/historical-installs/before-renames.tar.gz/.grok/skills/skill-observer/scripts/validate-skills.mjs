#!/usr/bin/env node

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { basename, join, resolve } from 'node:path';

const PACKAGE_ARGUMENT_SKILLS = new Set([
  'ai-slop-remover', 'autoconference', 'autoresearch', 'browser-drive', 'comment-checker',
  'debugging', 'deep-interview', 'frontend-ui-ux', 'git-master', 'hyperplan', 'init-deep',
  'lit-comprehend', 'lit-plan', 'lit-scientific-visualization', 'litgoal', 'litresearch',
  'litwork', 'refactor', 'remove-ai-slops', 'review-work', 'start-work', 'structural-search',
  'text-naturalization', 'visual-qa', 'wikify',
]);

function fail(code, message) {
  process.stderr.write(`FAIL ${code}: ${message}\n`);
  process.exit(1);
}

function isDirectory(path) {
  return existsSync(path) && statSync(path).isDirectory();
}

function isFile(path) {
  return existsSync(path) && statSync(path).isFile();
}

function scalar(value) {
  const quoted = value.match(/^(['"])(.*)\1$/);
  return quoted ? quoted[2] : value;
}

function frontmatter(content, skill) {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
  if (!match) fail('INVALID_FRONTMATTER', `${skill} missing opening YAML frontmatter`);
  const fields = new Map();
  for (const [index, line] of match[1].split(/\r?\n/).entries()) {
    if (!line.trim() || /^\s/.test(line)) continue;
    const field = line.match(/^([A-Za-z][A-Za-z0-9_-]*):\s*(.*?)\s*$/);
    if (!field) fail('INVALID_FRONTMATTER', `${skill} line ${index + 2} is not a supported top-level field`);
    fields.set(field[1], field[2]);
  }
  return { fields, end: match[0].length };
}

const input = process.argv[2] ?? join(process.cwd(), '.grok', 'skills');
if (process.argv.length > 3) fail('USAGE', 'validate-skills.mjs [skills-directory]');
const root = resolve(input);
if (!isDirectory(root)) fail('SKILLS_DIRECTORY_NOT_FOUND', root);

const directories = readdirSync(root, { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .sort((left, right) => left.name.localeCompare(right.name));
if (directories.length === 0) fail('NO_SKILLS', root);

for (const directory of directories) {
  const skill = directory.name;
  const path = join(root, skill, 'SKILL.md');
  if (!isFile(path)) fail('SKILL_FILE_MISSING', skill);
  const content = readFileSync(path, 'utf8');
  const parsed = frontmatter(content, skill);
  const name = scalar(parsed.fields.get('name') ?? '');
  const description = scalar(parsed.fields.get('description') ?? '').trim();

  if (!name) fail('REQUIRED_FIELD_MISSING', `${skill} name`);
  if (name !== basename(join(root, skill))) fail('NAME_MISMATCH', `${skill} declares ${name}`);
  if (!description) fail('REQUIRED_FIELD_MISSING', `${skill} description`);
  if (parsed.fields.get('user-invocable') !== 'true') {
    fail('INVALID_FRONTMATTER', `${skill} user-invocable must be literal true`);
  }

  const body = content.slice(parsed.end);
  const preamble = body.split(/^## /m)[0];
  const argument = preamble.match(/<([A-Za-z][A-Za-z0-9 _-]*)>/)?.[0];
  const argumentHint = scalar(parsed.fields.get('argument-hint') ?? '').trim();
  if (PACKAGE_ARGUMENT_SKILLS.has(skill) && !argumentHint) {
    fail('ARGUMENT_HINT_MISSING', `${skill} package contract requires argument-hint`);
  }
  if (argument && !argumentHint) {
    fail('ARGUMENT_HINT_MISSING', `${skill} preamble declares ${argument}`);
  }
}

process.stdout.write(`PASS skills=${directories.length}\n`);
