# Conference Report: {Title}

**Generated:** {date}
**Total Rounds:** {n}
**Total Iterations:** {sum across all researchers}
**Best Metric:** {value} ({direction}: {metric name})
**Review label:** {target-evidence | BUDGET_EXHAUSTED | blocked | cancelled | inconclusive}
**Synthesis digest:** {digest when available}

> `REVIEW_REQUIRED`: this report cannot programmatically claim family completion.

---

## Executive Summary

{2-3 sentences: what was researched, the best result, and the key insight from synthesis.}

## Best Result

- **Source:** Researcher {ID}, Round {n}, Iteration {i}
- **Change:** {what was different from baseline}
- **Metric Value:** {value} (baseline: {baseline}, improvement: {delta})

## Conference Timeline

| Round | Phase | Key Event | Metric |
|-------|-------|-----------|--------|
{rows}

## Per-Researcher Summary

| Researcher | Focus | Iterations | Best Metric | Kept Changes | Stuck Level |
|-----------|-------|------------|-------------|-------------|-------------|
{rows}

## Peer Review Summary

| Round | Validated | Challenged | Overturned |
|-------|-----------|------------|------------|
{rows}

## Key Findings

1. {Pattern discovered across researchers}
2. {What worked consistently}
3. {Surprising result from synthesis}

## Failed Approaches

1. {Approaches tried by multiple researchers that consistently failed}
2. {Dead ends worth documenting}

## Recommendations

- {Next steps}
- {Unexplored areas identified during synthesis}
