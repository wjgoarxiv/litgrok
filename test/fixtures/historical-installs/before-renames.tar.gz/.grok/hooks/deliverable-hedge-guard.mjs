#!/usr/bin/env node

// Host contract: exit 0 allows, exit 2 denies; timeouts, crashes, and malformed output fail-open and the write may proceed.
// This is a best-effort guard, not absolute enforcement.

import { extname, basename } from 'node:path';

const MAX_EVENT_BYTES = 1024 * 1024;
const READER_EXTENSIONS = new Set(['.adoc', '.asciidoc', '.htm', '.html', '.markdown', '.md', '.mdx', '.rst', '.tex', '.txt']);
const READER_BASENAMES = /^(?:authors|changelog|license|notice|readme)$/i;
const PATH_KEY = /^(?:file_?path|filename|path)$/i;
const CONTENT_KEY = /^(?:content|new_?string|patch|replacement|text)$/i;
const STATE_ENUM = /^(?:보류\s*중|(?:자료|근거|증거)\s*(?:없음|부재)|pending|on hold|not started|in progress|complete|completed|blocked)$/i;
const KOREAN_EVIDENCE_TOPIC = /(?:근거|증거|자료|데이터|측정\s*(?:값|치)|관측\s*값|관찰\s*기록|검토\s*기록|기록|출처|정보|수치|표본|샘플)/u;
const KOREAN_ABSENCE_MARKER = /(?:없(?:어(?:서)?|으며|고|습니다|다|음)|(?:(?:제공|확인|검증)되지|주어지지)\s*않(?:아(?:서)?|았(?:습니다|다)?|습니다|는다|음)?|부재)/u;
const KOREAN_ASSESSMENT_CONTEXT = /(?:접근성|효과성|안정성|평가|판단|산정|점수|등급|성과|결론|기준(?:별)?|검토|감사|심사)/u;
const KOREAN_UNSUPPORTED_CONCLUSION = /(?:(?:평가|판단|산정)할\s*수\s*없|알\s*수\s*없)/u;
const HEDGES = [
  { label: 'absent evidence', find: findKoreanAbsentEvidence },
  { label: 'deferred', pattern: /보류\s*중/u },
  { label: 'scope limit', pattern: /한정됩니다/u },
  { label: 'negated action', pattern: /하지\s*않았습니다/u },
  { label: 'negated action', pattern: /포함되지\s*않습니다/u },
  { label: 'self protection', pattern: /참고용/u },
  { label: 'self protection', pattern: /추가\s*검증이\s*필요/u },
  { label: 'deferred', pattern: /\b(?:pending|on hold|to be determined separately)\b/i },
  { label: 'absent evidence', pattern: /\b(?:no evidence yet|not yet substantiated)\b/i },
  { label: 'scope limit', pattern: /\blimited to the provided evidence\b/i },
  { label: 'negated action', pattern: /\b(?:was not performed|is not included)\b/i },
  { label: 'self protection', pattern: /\b(?:for reference only|may be incomplete|(?:additional|further) verification is required)\b/i },
];

function allow() {
  process.stdout.write(`${JSON.stringify({ decision: 'allow' })}\n`);
}

async function readEvent() {
  let input = '';
  for await (const chunk of process.stdin) {
    input += chunk;
    if (Buffer.byteLength(input) > MAX_EVENT_BYTES) return null;
  }
  try {
    return JSON.parse(input);
  } catch {
    return null;
  }
}

function stringLeaves(value, key = '', depth = 0, leaves = []) {
  if (depth > 12) return leaves;
  if (typeof value === 'string') {
    leaves.push({ key, value });
    return leaves;
  }
  if (!value || typeof value !== 'object') return leaves;
  for (const [childKey, childValue] of Object.entries(value)) stringLeaves(childValue, childKey, depth + 1, leaves);
  return leaves;
}

function readerFacing(path) {
  const file = basename(path);
  return READER_EXTENSIONS.has(extname(file).toLowerCase()) || READER_BASENAMES.test(file);
}

function looksLikeDataScalar(line) {
  const trimmed = line.trim().replace(/,$/, '');
  if (/^(?:["']?[-\w.]+["']?)\s*:\s*.+$/.test(trimmed)) return true;
  if (/^(?:["']?[-\w.]+["']?)\s*=\s*["'][^"']*["']$/.test(trimmed)) return true;
  if (/^[{[].*[}\]]$/.test(trimmed)) {
    try {
      JSON.parse(trimmed);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

function maskQuotedEnums(line) {
  return line.replace(/(["'`])([^\n"'`]{1,64})\1/g, (quoted, _quote, value) => (STATE_ENUM.test(value.trim()) ? ' '.repeat(quoted.length) : quoted));
}

function findKoreanAbsentEvidence(content) {
  const sentences = content.match(/[^\n.!?。！？]+(?:[.!?。！？]+|$)/gu) ?? [];
  for (const rawSentence of sentences) {
    const sentence = rawSentence.trim();
    const hasAssessmentContext = KOREAN_ASSESSMENT_CONTEXT.test(sentence);
    const evidenceIsAbsent = hasAssessmentContext && KOREAN_EVIDENCE_TOPIC.test(sentence) && KOREAN_ABSENCE_MARKER.test(sentence);
    const assessmentIsUnsupported = hasAssessmentContext && KOREAN_UNSUPPORTED_CONCLUSION.test(sentence);
    if (evidenceIsAbsent || assessmentIsUnsupported) return sentence;
  }
  return undefined;
}

function proseOnly(content) {
  const prose = [];
  let fenced = false;
  let statusTable = false;

  for (const line of content.split(/\r?\n/)) {
    if (/^\s*(?:```|~~~)/.test(line)) {
      fenced = !fenced;
      continue;
    }
    if (fenced) continue;

    if (/^\s*\|.*\|\s*$/.test(line)) {
      if (/\|\s*(?:status|state|상태)\s*\|/i.test(line)) statusTable = true;
      if (statusTable) continue;
    } else {
      statusTable = false;
    }

    if (looksLikeDataScalar(line)) continue;
    prose.push(maskQuotedEnums(line));
  }

  return prose.join('\n');
}

function pendingWrite(toolInput) {
  const leaves = stringLeaves(toolInput);
  const path = leaves.find(({ key, value }) => PATH_KEY.test(key) && !value.includes('\n'))?.value;
  if (!path || !readerFacing(path)) return null;
  const content = leaves.filter(({ key }) => CONTENT_KEY.test(key)).map(({ value }) => value).join('\n');
  return content ? { content, path } : null;
}

const event = await readEvent();
if (!event || event.hookEventName !== 'PreToolUse') {
  allow();
} else {
  const write = pendingWrite(event.toolInput);
  const prose = write ? proseOnly(write.content) : '';
  const violation = HEDGES
    .map(({ label, pattern, find }) => ({ label, match: find ? find(prose) : prose.match(pattern)?.[0] }))
    .find(({ match }) => match);

  if (!write || !violation) {
    allow();
  } else {
    const reason = `Reader-facing artifact hedge (${violation.label}) in ${write.path}: "${violation.match}". Move limitations to the reply or designated methodology paragraph.`;
    process.stdout.write(`${JSON.stringify({ decision: 'deny', reason })}\n`);
    process.exitCode = 2;
  }
}
