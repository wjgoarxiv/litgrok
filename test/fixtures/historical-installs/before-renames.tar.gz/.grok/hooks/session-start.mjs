#!/usr/bin/env node

import { pendingReviewState } from '../skills/skill-observer/scripts/skill-loop.mjs';

process.stdout.write('LitGrok payload present: skills, project rules, hooks, and the npx installer.\n');

let input = '';
for await (const chunk of process.stdin) {
  input += chunk;
  if (Buffer.byteLength(input) > 1024 * 1024) break;
}
try {
  const event = JSON.parse(input);
  const sessionId = process.env.GROK_SESSION_ID || event.sessionId;
  const workspaceRoot = process.env.GROK_WORKSPACE_ROOT || event.workspaceRoot;
  if (sessionId && workspaceRoot && event.sessionId === sessionId && event.workspaceRoot === workspaceRoot) {
    const state = pendingReviewState({
      cwd: workspaceRoot,
      env: { ...process.env, LITGROK_WORKSPACE_ROOT: workspaceRoot },
      sessionId,
    });
    if (state.pending) process.stdout.write(`LitGrok: pending review for session ${sessionId} — run /skill-observer review\n`);
  }
} catch {
  // The installed-payload banner is still useful when optional event state is unavailable.
}
